<nav>
    <ul>
        <li class="nav-item1"><a href="">Home</a></li>
        <li class="nav-item2"><a href="">Classic</a></li>
        <li class="nav-item3"><a href="">Sports</a></li>
        <li class="nav-item4"><a href="">SUV</a></li>
        <li class="nav-item5"><a href="">Trucks</a></li>
        <li class="nav-item6"><a href="">Used</a></li>
    </ul>
</nav>