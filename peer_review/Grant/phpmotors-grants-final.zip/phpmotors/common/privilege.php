<?php

$privilege = "<h3>Vehicle Management</h3><p>Use this link to manage the inventory.";
$privilege .= "<p><a href='/phpmotors/vehicles/'>Click Here</a> to add a new vehicle or classification.</p>";