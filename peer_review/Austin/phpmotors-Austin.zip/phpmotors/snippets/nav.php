<div id="navbar">
    <ul>
        <li class="nav-item"> <a  href="/home.php" title="PHP Motors Home Page">Home</a> </li>
        <li class="nav-item"> <a  href="#" title="Classic Cars">Classic</a> </li>
        <li class="nav-item"> <a  href="#" title="Sports Cars">Sports</a> </li>
        <li class="nav-item"> <a  href="#" title="Sports Utility Vehicles">SUV</a> </li>
        <li class="nav-item"> <a  href="#" title="Pickup Trucks">Trucks</a> </li>
        <li class="nav-item"> <a  href="#" title="Used Cars">Used</a> </li>
    </ul>
</div>