<header>
    <img class="header-logo" src="../images/site/logo.png" alt="php motors logo" />
    <h1>My Account</h1>
</header>