    <?php
    require '../components/header.php'
    ?>
    <?php
    require '../components/nav.php'
    ?>
    <?php
    require '../components/main.php'
    ?>
    <?php
    require '../components/footer.php'
    ?>